<?php if( !empty( $dato ) ): ?>
<p><a title="<?php echo e($dato); ?>" class="text-truncate d-inline-block" href="mailto:<?php echo e($dato); ?>" target="blank"><?php echo e($dato); ?></a></p>
<?php endif; ?><?php /**PATH /home/osolelar/hidratools_laravel/resources/views/layouts/general/email.blade.php ENDPATH**/ ?>
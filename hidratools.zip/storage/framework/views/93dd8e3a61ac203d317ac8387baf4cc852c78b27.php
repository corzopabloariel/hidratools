<div class="d-flex h-100 align-items-center justify-content-center py-5 text-white">
    <h1 class="text-center text-welcome">Bienvenido<br/><?php echo e(Auth::user()["name"]); ?></h1>
</div><?php /**PATH C:\Users\Pablo\Desktop\Laravel\hidratools\resources\views/auth/parts/index.blade.php ENDPATH**/ ?>
@if( !empty( $dato ) )
<p><a title="{{$dato}}" class="text-truncate d-inline-block" href="mailto:{{$dato}}" target="blank">{{$dato}}</a></p>
@endif